<?php $__env->startSection('about'); ?> active <?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

    <!--================ Start Feature Area =================-->
    <section class="feature_area section_gap_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="main_title">
                        <h2 class="mb-3"><?php echo e($id); ?> - qism mundarijasi</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <a href="<?php echo e(route('user.theme', ['theme_id' => $theme->id])); ?>">
                            <div class="single_feature">
                                <div class="icon"><span class="flaticon-book"></span></div>
                                <div class="desc">
                                    <h4 class="mt-3 mb-2"><?php echo e($theme->name); ?></h4>
                                    <p class="text-secondary">
                                        <?php echo e($theme->subtitle); ?>

                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
    <!--================ End Feature Area =================-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.header_footer_light', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\qiziqrli-onatili\resources\views/user/section.blade.php ENDPATH**/ ?>