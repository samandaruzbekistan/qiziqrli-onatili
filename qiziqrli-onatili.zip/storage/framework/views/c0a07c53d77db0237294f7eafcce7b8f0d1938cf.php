<?php $__env->startSection('about'); ?> active <?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>
        .quiz-wrapper {
            position: relative;
            display: block;
            width: 100%;
            height: auto;
        p.question-description {
            background: #19286C;
            color: white;
            padding: 25px 20px;
        }
        .options {
            width: 100%;
        }
        ul.options {
            position: relative;
            display: inline-block;
            vertical-align: top;
            width: 165px;
            list-style: none;
            border: 1px solid #19286C;
            text-align: center;
            padding: 0;
            margin: 0;
        li {
            border: 1px solid transparent;
            padding: 6px 8px;
        }
        li.title {
            background: #19286C;
            color: white;
        }
        li.option {
            display: block;
            position: relative;
            z-index: 50;
            font-size: 13px;
        }
        }
        .answers {
            display: inline-block;
            width: 335px;
            font-size: 13px;
            line-height: 20px;
        .target {
            display: inline-block;
            width: 110px;
            background: lightblue;
            margin: 0 3px;
            text-align:center;
        }
        }
        button[type="submit"] {
            display:block;
            position: relative;
            margin:10px auto;
            padding: 10px;
            background: #19286C;
            border: none;
            color: white;
            font-size: 16px;
        }
        }
        .lightbox-bg {
            display: none;
            position: absolute;
            z-index: 100;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: rgba( 0,0,0,.7 );
        }
        .status {
            display: none;
            position: absolute;
            z-index: 110;
            text-align:center;
            width: 80%;
            top: 220px;
            left: 47px;
        p {
            background: white;
            padding: 30px;
        }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <!--================ Start Feature Area =================-->
    <section class="feature_area section_gap_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="main_title">
                        <h2 class="mb-3"><?php echo e($theme->name); ?></h2>
                        <h3 class="mb-3 text-secondary"><?php echo e($theme->subtitle); ?></h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12">
                    <iframe src="<?php echo e(asset('pdf')); ?>/<?php echo e($topic->pdf); ?>" width="100%" height="600px"></iframe>
                </div>
                <div class="col-9 mt-5 quiz-wrapper">
                    <ul class="options">
                        <li class="title">Options</li>
                        <li class="option" data-target="carraway">Nick Carraway</li>
                        <li class="option" data-target="fitz">F. Scott Fitzgerald</li>
                        <li class="option" data-target="westegg">West Egg</li>
                        <li class="option" data-target="buchanan">Tom Buchanan</li>
                        <li class="option" data-target="daisy">Daisy</li>
                        <li class="option" data-target="ashes">Valley of Ashes</li>
                    </ul>
                    <table class="table answers ">
                        <thead>
                        <tr>
                            <th scope="col">English</th>
                            <th scope="col">O'zbekcha</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td ><span class="target" data-accept="fitz">&nbsp;</span></td>
                            <td>Otto</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-lg-12">
                    <div class="quiz-wrapper">
                        <p class="question-description">Fill in the blanks by dragging the missing answer.</p>
                        <div class="answers">
                            <ol>
                                <li><span class="target" data-accept="fitz">&nbsp;</span>, a native of St Paul, Minnesota, and also a member of the "Lost Generation" finished four novels including "This Side of Paradise".</li>
                                <li><span class="target" data-accept="carraway">&nbsp;</span> attended Yale with the large and brooding<span class="target" data-accept="buchanan">&nbsp;</span>.</li>
                                <li>George Wilson owns an unsuccessful garage in an area known as the <span class="target" data-accept="ashes">&nbsp;</span>, where Tom brings Nick for a party.</li>
                                <li>Jay Gatsby, the Buchanans, and Nick himself all make<span class="target" data-accept="westegg">&nbsp;</span>their home.</li>
                            </ol>
                        </div>
                        <button type="submit" value="submit">Submit</button>
                        <div class="lightbox-bg"></div>
                        <div class="status confirm">
                            <p>All Answers Answered</p>
                        </div>
                        <div class="status deny">
                            <p>Answers Remain</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Feature Area =================-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
        $(document).ready( function() {
            //initialize the quiz options
            var answersLeft = [];
            $('.quiz-wrapper').find('li.option').each( function(i) {
                var $this = $(this);
                var answerValue = $this.data('target');
                var $target = $('.answers .target[data-accept="'+answerValue+'"]');
                var labelText = $this.html();
                $this.draggable( {
                    revert: "invalid",
                    containment: ".quiz-wrapper"
                });

                if ( $target.length > 0 ) {
                    $target.droppable( {
                        accept: 'li.option[data-target="'+answerValue+'"]',
                        drop: function( event, ui ) {
                            $this.draggable('destroy');
                            $target.droppable('destroy');
                            $this.html('&nbsp;');
                            $target.html(labelText);
                            answersLeft.splice( answersLeft.indexOf( answerValue ), 1 );
                        }
                    });
                    answersLeft.push(answerValue);
                } else { }
            });
            $('.quiz-wrapper button[type="submit"]').click( function() {
                if ( answersLeft.length > 0 ) {
                    $('.lightbox-bg').show();
                    $('.status.deny').show();
                    $('.lightbox-bg').click( function() {
                        $('.lightbox-bg').hide();
                        $('.status.deny').hide();
                        $('.lightbox-bg').unbind('click');
                    });
                } else {
                    $('.lightbox-bg').show();
                    $('.status.confirm').show();
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.header_footer_light', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\qiziqrli-onatili\resources\views/user/show_theme.blade.php ENDPATH**/ ?>